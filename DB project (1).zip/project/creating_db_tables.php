<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "project_db";

// connecting sql

$conn = mysqli_connect($servername,$username,$password,$database);

if(!$conn)
{
    die("connection failed: ".mysqli_connect_error());
}

echo "connected Successfully";

// creating book table

// $sql = "CREATE TABLE Book (
//     isbn INT NOT NULL,
//     name VARCHAR(100) NOT NULL,
//     Author VARCHAR(60) NOT NULL,
//     publishdate DATE,
//     no_of_copies INT,
//     rating INT,
//     price FLOAT,
//     rent FLOAT,
//     img LONGBLOB,
//     PRIMARY KEY(isbn)
// );";

// // Creating table for customers
// $sql = "CREATE TABLE Customers (
//      cid INT NOT NULL,
//      fname VARCHAR(60) NOT NULL,
//      lname VARCHAR(60) NOT NULL,
//      residential_address VARCHAR(50),
//      phone_number INT,
//      province VARCHAR(50),
//      PRIMARY KEY(cid)
//      );";

// Creating table for Customer Credentials
// $sql = "CREATE TABLE ccredentials (
//      cid INT NOT NULL,
//      email_id VARCHAR(40) NOT NULL,
//      password1 VARCHAR(50) NOT NULL, 
//      PRIMARY KEY(cid)
//      );";

// Creating table for Admin
// $sql = "CREATE TABLE admin1 (
//     Eid INT NOT NULL,
//     first_name VARCHAR(50) NOT NULL,
//     last_name VARCHAR(50) NOT NULL,
//     password1 VARCHAR(40),
//     PRIMARY KEY(Eid)
//     );";

// Creating table for publish
// $sql = "CREATE TABLE  publish (
//     pid INT NOT NULL,
//     isbn_no INT ,
//     country VARCHAR(30),
//     PRIMARY KEY(pid)
//     );";

// Creating table for rent
// $sql = "CREATE TABLE  rent (
//     isbn_no INT NOT NULL,
//     Cid INT NOT NULL,
//     no_of_copies INT,
//     rent FLOAT,
//     PRIMARY KEY(isbn_no,cid)
//     );";

// Creating table for Author
// $sql = "CREATE TABLE  Author (
//     Author_id INT NOT NULL,
//     fname VARCHAR(60) NOT NULL,
//     lname VARCHAR(60) NOT NULL,
//     ISBN_no INT,
//     PRIMARY KEY(Author_id)
//     );";

// Creating table for bookstock
// $sql = "CREATE TABLE  bookstock(
//     ISBN_no INT,
//     stocklevel_used INT,
//     stocklevel_new INT,
//     PRIMARY KEY(Isbn_no)
//     );";




// adding foreign key

// $sql = "ALTER TABLE BOOKSTOCK ADD CONSTRAINT 
// FK_ISBN FOREIGN KEY(ISBN_NO) REFERENCES BOOK(ISBN);";

// $sql = "ALTER TABLE PUBLISH ADD CONSTRAINT 
// FK_PISBN FOREIGN KEY(ISBN_NO) REFERENCES BOOK(ISBN);";

// $sql = "ALTER TABLE RENT ADD CONSTRAINT 
// FK_RISBN FOREIGN KEY(ISBN_NO) REFERENCES BOOK(ISBN);";

// $sql = "ALTER TABLE AUTHOR ADD CONSTRAINT 
// FK_AISBN FOREIGN KEY(ISBN_NO) REFERENCES BOOK(ISBN);";

// $sql = "ALTER TABLE CCREDENTIALS ADD CONSTRAINT 
// FK_CID FOREIGN KEY(CID) REFERENCES CUSTOMERS(CID);";

// $sql = "ALTER TABLE RENT ADD CONSTRAINT 
// FK_RCID FOREIGN KEY(CID) REFERENCES CUSTOMERS(CID);";

// $sql = "ALTER TABLE customers Modify cid INT AUTO_INCREMENT;";
// $sql = "ALTER TABLE customers AUTO_INCREMENT = 101;";

// $sql = "ALTER TABLE admin1 Modify eid INT AUTO_INCREMENT;";
// $sql = "ALTER TABLE admin1 MODIFY email_id VARCHAR(60);";

// $sql = "CREATE TABLE o1(
//     order_id int,
//     isbn_no int,
//     cid int,
//     pdate date,
//     PRIMARY KEY(order_id)
// );";

// $sql = "ALTER TABLE o1 ADD CONSTRAINT 
// FK_o1 FOREIGN KEY(CID) REFERENCES CUSTOMERS(CID);";

// $sql = "ALTER TABLE o1 ADD CONSTRAINT 
// FK_o1 FOREIGN KEY(CID) REFERENCES CUSTOMERS(CID);";
$sql = "ALTER TABLE o1 ADD CONSTRAINT 
Pk_o1 PRIMARY KEY(cid,isbn_no);";

// $sql = "ALTER TABLE o1 ADD order_id INT";


// $sql = "ALTER TABLE o1 ADD CONSTRAINT 
// FK_isbn FOREIGN KEY(isbn_no) REFERENCES book(isbn);";

$result = mysqli_query($conn,$sql); 

if ($result) 
{
    // echo "table created successfully";
    echo "Table updated successfully successfully";
} 
    

else 
{
   echo "creating books table: ". mysqli_error($conn);
}


mysqli_close($conn);
?>