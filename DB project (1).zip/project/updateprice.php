<!doctype html>
<html lang="en">
<?php
  session_start();
  $isbn = $_POST["isbn"];
 ?> 
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="p1.css">

    <title>Update book price</title>
  </head>
  <body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!doctype html>
    <html lang="en">
      <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
    
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
      </head>
      <body>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

        <form class="row g-3" action = "updatebook1.php" method="POST" style="margin:auto; padding: 50px; width: 50%; height: 50%;">
        <h2>Update price</h2>
        <div class="col-md-6">
          <label for="inputPassword4" class="form-label">Update price:</label>
          <input type="text" class="form-control" id="inputPassword4" name="priceUpdate">
          <br>
          <button name="isbn" value="<?php echo $isbn; ?>" class="btn btn-primary">Update</button>
          <!-- <button name="isbn" value="' .  $isbn . '" class="btn btn-primary">Update</button> -->
        </div>
    </form>
    <?php
    // echo
    ?>
    </body>
    </html>

  </body>
</html>