<?php

   $fname = $_POST["fname"];
   $lname = $_POST["lname"];
   $email1 = $_POST["e1"];
   $passwd = $_POST["passwd"];
   $cpasswd = $_POST["cpasswd"];
   $pnumber = $_POST["pnumber"];
   $address = $_POST["address"];
   $city = $_POST["city"];
   $province = $_POST["province"];
   $option = $_POST["inlineRadioOptions"];

$servername = "localhost";
$username = "root";
$password = "";
$database = "project_db";


// create connection

$conn = mysqli_connect($servername,$username,$password,$database);

// check connection

if(!$conn) {
    die("connection failed: ".mysqli_connect_error());
}

echo "connected Successfully";

if($option == "option1")
{
    // add record in ccredentials
    $sql1 = "INSERT INTO customers (fname, lname, residential_address, phone_number, province) VALUES ('$fname', '$lname', '$address', $pnumber, '$province')";
    $result1 = mysqli_query($conn,$sql1);    
    
    if ($result1) 
    {
        // echo "Thanks for registring. Your account has been created <br> ";
       ?>
       <!-- <script>
        window.alert("Thanks for registring. Your account has been created");
       </script> -->
    <?php
    }

    else
    {
        echo "Error in inserting: ". mysqli_error($conn);
    }

    $sql2 = "SELECT cid From customers where fname ='$fname' AND lname ='$lname' AND phone_number =$pnumber";
    $result_cid = mysqli_query($conn,$sql2);
    $row_cid = mysqli_fetch_assoc($result_cid);

    if ($row_cid) {
        // Access individual column values like $row_cid['cid']
        $cid = $row_cid['cid'];
        echo $cid;
        // Do something with $cid_value
    } else {
        // No rows in the result set
    }

    $sql3= "INSERT INTO ccredentials(cid,email_id,password1) values ($cid,'$email1','$passwd')";

    $result2 = mysqli_query($conn,$sql3);

    if ($result2) 
    {
        ?>
          <script>
        window.alert("Thanks for registring. Your account has been created");
       </script>
        <?php
    }

    else
    {
        echo "Error in inserting credentuals: ". mysqli_error($conn);
    }    


}

else{
    // add record in admin1
    $sql = "INSERT INTO admin1 (first_name,last_name,password1,email_id) values ('$fname','$lname','$passwd','$email1')";
    
    $result = mysqli_query($conn,$sql);

    if ($result) 
    {
    
        // echo "Thanks for joining as the team for the book store <br>";
    ?>
        <script>
            window.alert("Thanks for joining as the team for the book store");
        </script>
    <?php
    } 
    

    else 
    {
    echo "Error in inserting: ". mysqli_error($conn);
    }
}

mysqli_close($conn);

?>

<script>
    window.location.href = "customer.php"
</script>