<?php
    $option = $_POST["inlineRadioOptions"];
    $email1 = $_POST["e1"];
    $passwd = $_POST["passwd"];
    

// echo "option = $option <br>";
// echo "email1 = $email1 <br>";
// echo "passwd = $passwd <br>";

// check if any input is empty ?

if($email1 == "" || $passwd == "" || $option == "")
{
    ?>
    <script>
        window.alert("Please fill all the section of the form.");
        window.location.href = "login.html";
    </script>
    <?php
}

$servername = "localhost";
$username = "root";
$password = "";
$database = "project_db";


// create connection

$conn = mysqli_connect($servername,$username,$password,$database);

// check connection

if(!$conn) {
    die("connection failed: ".mysqli_connect_error());
}


if($option == "customer")
{
    validate_credentials($email1,$passwd,"ccredentials",$conn);
    $sql = "SELECT cid FROM ccredentials WHERE email_id ='$email1'";

    $result = mysqli_query($conn,$sql);
    
    if (!$result) 
    {
        echo "Error: ". mysqli_error($conn);
    }

    $row_new = mysqli_fetch_assoc($result); 

    if($row_new)
    {
        $_SESSION["cid"] = $row_new['cid'];
        $cid1 = $row_new['cid'];
    }

    $sql = "SELECT cid,fname,lname,residential_address,phone_number,province FROM customers WHERE cid= $cid1";

    $result = mysqli_query($conn,$sql);
    
    if (!$result) 
    {
        echo "Error: ". mysqli_error($conn);
    }

    $row_new = mysqli_fetch_assoc($result); 

    if($row_new)
    {
        $_SESSION["first_name"] = $row_new['fname'];
        $_SESSION["last_name"] = $row_new['lname'];
        $_SESSION["email"] = $email1;
        $_SESSION["address"] = $row_new['residential_address'];
        $_SESSION["phone_number"] = $row_new['phone_number'];
        $_SESSION["province"] = $row_new['province'];
        $_SESSION["user"] = $row_new['fname'];

        ?>
        <script>
            window.location.href="customer.php";
        </script>
        <?php

        // echo"session <br>";
        // echo"<br>";
        // echo $_SESSION["first_name"];
        // echo"<br>";
        // echo $_SESSION["last_name"];
        // echo"<br>";
        // echo $_SESSION["email"];
        // echo"<br>";
        // echo $_SESSION["address"];
        // echo"<br>";
        // echo $_SESSION["phone_number"];
        // echo"<br>";
        // echo $_SESSION["province"];
        // session_unset();
        // session_destroy();
    }
}

else if($option == "admin")
{
    validate_credentials($email1,$passwd,"admin1",$conn);
    $sql = "SELECT eid,first_name,last_name FROM admin1 WHERE email_id ='$email1'";
    
    $result = mysqli_query($conn,$sql);
    
    if (!$result) 
    {
        echo "Error: ". mysqli_error($conn);
    }

    $row_new = mysqli_fetch_assoc($result); 

    if($row_new)
    {
        $_SESSION["eid"] = $row_new['eid'];
        $_SESSION["first_name"] = $row_new['first_name'];
        $_SESSION["last_name"] = $row_new['last_name'];
        $_SESSION["email"] = $email1;
        $_SESSION["user"] = $row_new['first_name'];

        ?>
        <script>
            window.location.href="admin.php";
        </script>
        <?php

        // echo"session <br>";
        // echo $_SESSION["eid"];
        // echo"<br>";
        // echo $_SESSION["first_name"];
        // echo"<br>";
        // echo $_SESSION["last_name"];
        // echo"<br>";
        // echo $_SESSION["email"];
        // session_unset();
        // session_destroy();
    } 
}


function validate_credentials($email1,$passwd,$table,$conn )
{
    $sql = "SELECT * FROM $table WHERE email_id= '$email1' AND  password1='$passwd'";
    // $sql = "SELECT * FROM admin1 WHERE email_id= '$email1' AND  password1='$passwd'";
    
    $result = mysqli_query($conn,$sql);
    
    if ($result) 
    {   
        // echo "table created successfully";
        echo "Successful";
    } 
    else 
    {
        echo "Error: ". mysqli_error($conn);
    }

    $row = mysqli_fetch_assoc($result); 

    if($row)
    {
        echo "valid passwd";
        if(session_status() === PHP_SESSION_NONE)
        {
            // start session
            session_start();
        }

    }

    else{
        // echo "Invalid login details";
        ?>
        <script>
            window.alert("Invalid login details");
            window.location.href="login.html";
        </script>
        <?php
    }



}







// $sql = "";

// $result = mysqli_query($conn,$sql);


    




?>