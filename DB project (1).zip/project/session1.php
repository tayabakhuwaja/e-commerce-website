<?php
$isbn = $_POST['isbn'];
echo $isbn;  
// $_SESSION['cart'] = $isbn;
if(!isset($_SESSION['cart']))
{
    $_SESSION['count'] = 0;
}
$_SESSION['count'] = $_SESSION['cart']++;

// echo $_SESSION['cart']."<br>";
// echo $_SESSION['count']."<br>";


?>