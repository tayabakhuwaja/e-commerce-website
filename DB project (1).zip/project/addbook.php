<?php
   
$bname = $_POST["bname"];
$author = $_POST["author"];
$pvdate = $_POST ["pdate"]; 
$pdate = date("y-m-d", strtotime($pvdate));  
// echo"$pdate<br>";
$isbn = $_POST["isbn"];
$copies = $_POST["copies"];
$rating = $_POST["rating"];
$price = $_POST["price"];
$rent = $_POST["rent"];
echo"$pdate <br>";
echo"$isbn <br>";
echo"$copies <br>";
echo"$price <br>";
echo"$rent <br>";
echo"$pdate <br>";

// $image1 = $_POST["image1"];


// $sql = "INSERT INTO BOOK (isbn,name,author,publishdate,no_of_copies,rating,price,rent) VALUES ($isbn,'$bname','$author',$pvdate,$copies,$rating,$price,$rent);";

$sql = "INSERT INTO BOOK (isbn, name, author, publishdate, no_of_copies, rating, price, rent) VALUES ($isbn, '$bname', '$author', '$pdate', $copies, $rating, $price, $rent);";


$servername = "localhost";
$username = "root";
$password = "";
$database = "project_db";


// create connection

$conn = mysqli_connect($servername,$username,$password,$database);

// check connection

if(!$conn) {
 die("connection failed: ".mysqli_connect_error());
}

echo "connected Successfully";


// $sql = "INSERT INTO book (isbn,name,author,no_of_copies,rating,price,rent) VALUES ($isbn,'$bname','$author',$copies,$rating,$price,$rent)";

// $sql = "INSERT INTO book VALUES($isbn,'$bname','$author', '00-00-0000',$copies,$rating,$price,$rent)";

$result = mysqli_query($conn,$sql);    

if ($result) 
{
    echo "The book has been added.";
//    ?>
   <script>
    window.alert("The book has been added.");
    window.location.href = "admin.php";
//    </script>z
 <?php
}

else
{
    echo "Error in inserting: ". mysqli_error($conn);
    ?>
    <script>
        window.location.href ="addbook.php";
    </script>
    <?php
}
mysqli_close($conn);
?>