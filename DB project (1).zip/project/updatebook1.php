<h1>update</h1>
<?php
  session_start();
  $isbn = $_POST["isbn"];
  $new_price = $_POST["priceUpdate"];
  echo "$isbn <br>";
  echo "$new_price <br>";

    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "project_db";

    $conn = mysqli_connect($servername,$username,$password,$database);

    if(!$conn) {
      die("connection failed: ".mysqli_connect_error());
    }
  
    // $sql = "UPDATE book SET price = $new_price WHERE isbn =$isbn";
    $sql = "update book SET price = $new_price WHERE isbn = $isbn";
    
    $result = mysqli_query($conn,$sql);

    if ($result) 
    { 
      ?>
      <script>
        window.alert("The book price has been deleted.");
        window.location.href = "viewbooka.php";
      </script> 
      <?php     
    }
    else 
    {
      echo "Error in inserting: ". mysqli_error($conn);
    }
      mysqli_close($conn);
?>