<?php
        session_start();
        echo $_SESSION["user"];
        session_unset();
        session_destroy();
        ?>
        <script>
        window.location.href = "customer.php";
        </script>
?>
