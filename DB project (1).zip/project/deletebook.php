<?php
    session_start();
    $isbn = $_POST["isbn"];
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "project_db";

    $conn = mysqli_connect($servername,$username,$password,$database);

    if(!$conn) {
      die("connection failed: ".mysqli_connect_error());
    }
  
    $sql = "DELETE FROM book WHERE isbn =$isbn";
    
    $result = mysqli_query($conn,$sql);

    if ($result) 
    { 
      ?>
      <script>
        window.alert("The book has been deleted.");
        window.location.href = "admin.php";
      </script> 
      <?php     
    }
    else 
    {
      echo "Error in inserting: ". mysqli_error($conn);
    }
      mysqli_close($conn);
?>