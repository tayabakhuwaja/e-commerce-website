<?php
$servername = "localhost";
$username = "root";
$password = "";


// create connection

$conn = mysqli_connect($servername,$username,$password);

// check connection

if(!$conn) {
    die("connection failed: ".mysqli_connect_error());
}

echo "connected Successfully";


//Creating a Database through php:
$sql= "Create Database project_db";
$result  = mysqli_query($conn, $sql); 

if ($result) {
echo "Database created successfully";
} 

else {
echo "creating database: ". mysqli_error($conn);
}

mysqli_close($conn);
?>