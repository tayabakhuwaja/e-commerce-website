<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Admin</title>
  </head>
  <body>
  <?php
      session_start(); 
    ?>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
        <!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<?php
include('customer_navbar.php');
?>
<div id="nav_bar">
     <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            /* margin: 0; */
            /* padding: 0; */
            /* display: flex; */
            /* justify-content: center; */
            /* align-items: center; */
            /* height: 100vh; */
        }

        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
    <title>Book Records</title>

    
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "project_db";

    $conn = mysqli_connect($servername,$username,$password,$database);

    if(!$conn) {
      die("connection failed: ".mysqli_connect_error());
    }
  
    $sql = "SELECT *FROM book";
    
    $result = mysqli_query($conn,$sql);

    if ($result) 
    {
      $num = mysqli_num_rows($result);  
      echo"$num records found. <br>";

      // while($row = mysqli_fetch_assoc($result)){
      //   echo "ISBN: " . $row['isbn'] ."Name: " .$row['name']. "Author: " . $row['Author']."Publish date: ". $row['publishdate']."Total Copies: ". $row['no_of_copies'] . "Rating: ". $row['rating']. "Price: ". $row['price']."Rent: " .$row['rent'];
      //   echo "<br>";
      // }
      ?>
      <div class="flexbox">
        <table class="table">
            <thead>
                <tr>
                    <th>ISBN</th>
                    <th>Name</th>
                    <th>Author</th>
                    <th>Publish Date</th>
                    <th>Total Copies</th>
                    <th>Rating</th>
                    <th>Price</th>
                    <th>Rent</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i =0;
                while ($row = mysqli_fetch_assoc($result)) {
                    $i++;
                  	$arr_isbn[$i] =$row['isbn'];
                    echo "<tr>";
                    echo "<td>" . $row['isbn'] . "</td>";
                    echo "<td>" . $row['name'] . "</td>";
                    echo "<td>" . $row['Author'] . "</td>";
                    echo "<td>" . $row['publishdate'] . "</td>";
                    echo "<td>" . $row['no_of_copies'] . "</td>";
                    echo "<td>" . $row['rating'] . "</td>";
                    echo "<td>" . $row['price'] . "</td>";
                    echo '<td>
                    <form action="session1.php" method="post">
                    <button name="isbn" value="' . $row['isbn'] . '" class="btn btn-primary">Add to cart</button>
                    </form>
                    </td>'; // Add Button 
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
         </div>
        <?php
    }
        else 
        {
          echo "Error in inserting: ". mysqli_error($conn);
        }

      mysqli_close($conn);

    ?>

  </body>
</html>